from django.urls import path

from . import views

app_name = "tareas"
urlpatterns = [
    path("", views.TareaListView.as_view(), name="index"),
    path("crear/", views.TareaCreateView.as_view(), name="crear"),
    path("<int:pk>/", views.TareaUpdateView.as_view(), name="editar"),
    path("<int:pk>/eliminar", views.TareaDeleteView.as_view(), name="eliminar")
]
