from django.db import models
from django.contrib.auth.models import User


class Tarea(models.Model):
    titulo = models.CharField(max_length=200)
    completado = models.BooleanField(default=False)
    usuario = models.ForeignKey(User, on_delete=models.CASCADE)

    def __str__(self):
        return f"Título: {self.titulo} - Completado: {"Sí" if self.completado else "No"}"
