from .models import Tarea
from django.views.generic.list import ListView
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.contrib.auth.mixins import LoginRequiredMixin
from django.urls import reverse_lazy


class TareaListView(LoginRequiredMixin, ListView):
    model = Tarea

    def get_queryset(self):
        return self.model.objects.filter(usuario=self.request.user).order_by("-id")


class TareaCreateView(LoginRequiredMixin, CreateView):
    model = Tarea
    fields = ["titulo"]
    success_url = reverse_lazy("tareas:index")

    def form_valid(self, form):
        form.instance.usuario = self.request.user
        return super().form_valid(form)


class TareaUpdateView(LoginRequiredMixin, UpdateView):
    model = Tarea
    fields = ["titulo", "completado"]
    success_url = reverse_lazy("tareas:index")

    def get_queryset(self):
        return self.model.objects.filter(usuario=self.request.user)


class TareaDeleteView(LoginRequiredMixin, DeleteView):
    model = Tarea
    success_url = reverse_lazy("tareas:index")

    def get_queryset(self):
        return self.model.objects.filter(usuario=self.request.user)
